#!/bin/bash

export LC_ALL=C

sort -m *.words > mergedWords.txt

uniq -c mergedWords.txt | sort -nr > countsOfWords
