#!/bin/bash

wget https://pages.stat.wisc.edu/~jgillett/DSCP/CHTC/wordCounting/shakespeare.tar

tar -xvf shakespeare.tar

find shakespeare/*/* -type f > playList.txt
