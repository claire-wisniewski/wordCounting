#!/bin/bash

infile="$1"
outfile="$(basename "$infile").words"

cat "$infile" \
    | tr '[:upper:]' '[:lower:]' \
    | sed -e 's/[[:punct:]]//g' \
    | sed -e 's/[ \t][ \t]*/\n/g' \
    | grep -v '^[ ]*$' \
    | sort \
    > "$outfile"
