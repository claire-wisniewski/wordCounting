#!/bin/bash

rm *.words
rm -r error
rm -r log
rm -r output
rm -r shakespeare
rm shakespeare.tar
rm playList.txt
rm mergedWords.txt
rm words.dag.condor.sub
rm words.dag.dagman.log
rm words.dag.dagman.out
rm words.dag.lib.err
rm words.dag.lib.out
rm words.dag.lock
rm words.dag.nodes.log
rm words.dag.metrics
